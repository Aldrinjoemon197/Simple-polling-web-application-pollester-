# Simple-webapplication-for-polling.
This project will help you to create a simple webapplication for polling using Django.
